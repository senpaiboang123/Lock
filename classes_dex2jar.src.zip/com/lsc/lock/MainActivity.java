package com.lsc.lock;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.widget.Toast;

public class MainActivity
  extends Activity
{
  private static final String a = MainActivity.class.getSimpleName();
  private DevicePolicyManager b;
  private ComponentName c;
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt2 == -1) {
      this.b.lockNow();
    }
    for (;;)
    {
      finish();
      return;
      Toast.makeText(this, 2130968579, 1).show();
    }
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    this.b = ((DevicePolicyManager)getSystemService("device_policy"));
    this.c = new ComponentName(this, ScreenLockDeviceAdminReceiver.class);
    if (!this.b.isAdminActive(this.c))
    {
      Log.d(a, "Main : admin is false");
      Intent localIntent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
      localIntent.putExtra("android.app.extra.DEVICE_ADMIN", this.c);
      localIntent.putExtra("android.app.extra.ADD_EXPLANATION", getString(2130968582));
      startActivityForResult(localIntent, 0);
    }
    for (;;)
    {
      Process.killProcess(Process.myPid());
      return;
      Log.d(a, "Main : admin is true");
      this.b.lockNow();
      finish();
    }
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     com.lsc.lock.MainActivity
 * JD-Core Version:    0.7.0.1
 */