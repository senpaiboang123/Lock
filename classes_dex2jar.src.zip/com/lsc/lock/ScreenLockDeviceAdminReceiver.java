package com.lsc.lock;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

public class ScreenLockDeviceAdminReceiver
  extends DeviceAdminReceiver
{
  public void onDisabled(Context paramContext, Intent paramIntent)
  {
    super.onDisabled(paramContext, paramIntent);
    Toast.makeText(paramContext, 2130968581, 1).show();
    Intent localIntent = new Intent("android.intent.action.DELETE", Uri.fromParts("package", "net.xcoda.android.screenlock", null));
    localIntent.addFlags(268435456);
    paramContext.startActivity(localIntent);
  }
  
  public void onEnabled(Context paramContext, Intent paramIntent)
  {
    super.onEnabled(paramContext, paramIntent);
    Toast.makeText(paramContext, 2130968580, 1).show();
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     com.lsc.lock.ScreenLockDeviceAdminReceiver
 * JD-Core Version:    0.7.0.1
 */