package android.support.v4.app;

import android.os.Bundle;

final class u
{
  private final String a;
  private final Class b;
  private final Bundle c;
  private Fragment d;
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.u
 * JD-Core Version:    0.7.0.1
 */