package android.support.v4.app;

public abstract class w
{
  public boolean a()
  {
    return false;
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.w
 * JD-Core Version:    0.7.0.1
 */