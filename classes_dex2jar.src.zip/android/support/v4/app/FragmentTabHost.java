package android.support.v4.app;

import android.content.Context;
import android.os.Parcelable;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import java.util.ArrayList;

public class FragmentTabHost
  extends TabHost
  implements TabHost.OnTabChangeListener
{
  private final ArrayList a;
  private Context b;
  private l c;
  private int d;
  private TabHost.OnTabChangeListener e;
  private u f;
  private boolean g;
  
  private v a(String paramString, v paramv)
  {
    Object localObject1 = null;
    int i = 0;
    Object localObject2;
    if (i < this.a.size())
    {
      localObject2 = (u)this.a.get(i);
      if (!u.b((u)localObject2).equals(paramString)) {
        break label202;
      }
    }
    for (;;)
    {
      i++;
      localObject1 = localObject2;
      break;
      if (localObject1 == null) {
        throw new IllegalStateException("No tab known for tag " + paramString);
      }
      if (this.f != localObject1)
      {
        if (paramv == null) {
          paramv = this.c.a();
        }
        if ((this.f != null) && (u.a(this.f) != null)) {
          paramv.a(u.a(this.f));
        }
        if (localObject1 != null)
        {
          if (u.a(localObject1) != null) {
            break label190;
          }
          u.a(localObject1, Fragment.a(this.b, u.c(localObject1).getName(), u.d(localObject1)));
          paramv.a(this.d, u.a(localObject1), u.b(localObject1));
        }
      }
      for (;;)
      {
        this.f = localObject1;
        return paramv;
        label190:
        paramv.b(u.a(localObject1));
      }
      label202:
      localObject2 = localObject1;
    }
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    String str = getCurrentTabTag();
    v localv1 = null;
    int i = 0;
    if (i < this.a.size())
    {
      u localu = (u)this.a.get(i);
      u.a(localu, this.c.a(u.b(localu)));
      if ((u.a(localu) != null) && (!u.a(localu).d()))
      {
        if (!u.b(localu).equals(str)) {
          break label98;
        }
        this.f = localu;
      }
      for (;;)
      {
        i++;
        break;
        label98:
        if (localv1 == null) {
          localv1 = this.c.a();
        }
        localv1.a(u.a(localu));
      }
    }
    this.g = true;
    v localv2 = a(str, localv1);
    if (localv2 != null)
    {
      localv2.a();
      this.c.b();
    }
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    this.g = false;
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    FragmentTabHost.SavedState localSavedState = (FragmentTabHost.SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.getSuperState());
    setCurrentTabByTag(localSavedState.a);
  }
  
  protected Parcelable onSaveInstanceState()
  {
    FragmentTabHost.SavedState localSavedState = new FragmentTabHost.SavedState(super.onSaveInstanceState());
    localSavedState.a = getCurrentTabTag();
    return localSavedState;
  }
  
  public void onTabChanged(String paramString)
  {
    if (this.g)
    {
      v localv = a(paramString, null);
      if (localv != null) {
        localv.a();
      }
    }
    if (this.e != null) {
      this.e.onTabChanged(paramString);
    }
  }
  
  public void setOnTabChangedListener(TabHost.OnTabChangeListener paramOnTabChangeListener)
  {
    this.e = paramOnTabChangeListener;
  }
  
  @Deprecated
  public void setup()
  {
    throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentTabHost
 * JD-Core Version:    0.7.0.1
 */