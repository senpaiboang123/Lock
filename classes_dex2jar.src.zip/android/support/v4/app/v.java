package android.support.v4.app;

public abstract class v
{
  public abstract int a();
  
  public abstract v a(int paramInt, Fragment paramFragment, String paramString);
  
  public abstract v a(Fragment paramFragment);
  
  public abstract v b(Fragment paramFragment);
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.v
 * JD-Core Version:    0.7.0.1
 */