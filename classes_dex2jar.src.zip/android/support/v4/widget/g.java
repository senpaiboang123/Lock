package android.support.v4.widget;

import android.graphics.Canvas;

class g
  implements h
{
  public void a(Object paramObject, int paramInt1, int paramInt2)
  {
    i.a(paramObject, paramInt1, paramInt2);
  }
  
  public boolean a(Object paramObject)
  {
    return i.a(paramObject);
  }
  
  public boolean a(Object paramObject, float paramFloat)
  {
    return i.a(paramObject, paramFloat);
  }
  
  public boolean a(Object paramObject, Canvas paramCanvas)
  {
    return i.a(paramObject, paramCanvas);
  }
  
  public void b(Object paramObject)
  {
    i.b(paramObject);
  }
  
  public boolean c(Object paramObject)
  {
    return i.c(paramObject);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.g
 * JD-Core Version:    0.7.0.1
 */