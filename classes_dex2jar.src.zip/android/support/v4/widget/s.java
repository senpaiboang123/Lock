package android.support.v4.widget;

public abstract interface s {}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.s
 * JD-Core Version:    0.7.0.1
 */