package android.support.v4.widget;

import android.view.View;

public abstract class aa
{
  public int a(View paramView)
  {
    return 0;
  }
  
  public int a(View paramView, int paramInt1, int paramInt2)
  {
    return 0;
  }
  
  public void a(int paramInt) {}
  
  public void a(int paramInt1, int paramInt2) {}
  
  public void a(View paramView, float paramFloat1, float paramFloat2) {}
  
  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public abstract boolean a(View paramView, int paramInt);
  
  public int b(View paramView)
  {
    return 0;
  }
  
  public int b(View paramView, int paramInt1, int paramInt2)
  {
    return 0;
  }
  
  public void b(int paramInt1, int paramInt2) {}
  
  public void b(View paramView, int paramInt) {}
  
  public boolean b(int paramInt)
  {
    return false;
  }
  
  public int c(int paramInt)
  {
    return paramInt;
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.aa
 * JD-Core Version:    0.7.0.1
 */