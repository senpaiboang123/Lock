package android.support.v4.widget;

import android.view.View;

abstract interface u
{
  public abstract void a(SlidingPaneLayout paramSlidingPaneLayout, View paramView);
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.u
 * JD-Core Version:    0.7.0.1
 */