package android.support.v4.widget;

import android.support.v4.view.x;
import android.view.View;

class v
  implements u
{
  public void a(SlidingPaneLayout paramSlidingPaneLayout, View paramView)
  {
    x.a(paramSlidingPaneLayout, paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.v
 * JD-Core Version:    0.7.0.1
 */