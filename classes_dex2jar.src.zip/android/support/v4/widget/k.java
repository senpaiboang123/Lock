package android.support.v4.widget;

abstract interface k
{
  public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public abstract boolean a(Object paramObject);
  
  public abstract int b(Object paramObject);
  
  public abstract int c(Object paramObject);
  
  public abstract boolean d(Object paramObject);
  
  public abstract void e(Object paramObject);
  
  public abstract int f(Object paramObject);
  
  public abstract int g(Object paramObject);
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.k
 * JD-Core Version:    0.7.0.1
 */