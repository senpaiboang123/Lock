package android.support.v4.widget;

import android.graphics.Canvas;

class f
  implements h
{
  public void a(Object paramObject, int paramInt1, int paramInt2) {}
  
  public boolean a(Object paramObject)
  {
    return true;
  }
  
  public boolean a(Object paramObject, float paramFloat)
  {
    return false;
  }
  
  public boolean a(Object paramObject, Canvas paramCanvas)
  {
    return false;
  }
  
  public void b(Object paramObject) {}
  
  public boolean c(Object paramObject)
  {
    return false;
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.f
 * JD-Core Version:    0.7.0.1
 */