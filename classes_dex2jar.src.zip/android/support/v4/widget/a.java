package android.support.v4.widget;

import android.view.View;

public abstract interface a
{
  public abstract void a(int paramInt);
  
  public abstract void a(View paramView);
  
  public abstract void a(View paramView, float paramFloat);
  
  public abstract void b(View paramView);
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.a
 * JD-Core Version:    0.7.0.1
 */