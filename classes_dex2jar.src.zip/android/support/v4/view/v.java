package android.support.v4.view;

import android.view.VelocityTracker;

abstract interface v
{
  public abstract float a(VelocityTracker paramVelocityTracker, int paramInt);
  
  public abstract float b(VelocityTracker paramVelocityTracker, int paramInt);
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.v
 * JD-Core Version:    0.7.0.1
 */