package android.support.v4.view;

import android.view.View;

class ai
{
  public static int a(View paramView)
  {
    return paramView.getOverScrollMode();
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ai
 * JD-Core Version:    0.7.0.1
 */