package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

class ab
  extends aa
{
  long a()
  {
    return aj.a();
  }
  
  public void a(View paramView, int paramInt, Paint paramPaint)
  {
    aj.a(paramView, paramInt, paramPaint);
  }
  
  public void a(View paramView, Paint paramPaint)
  {
    a(paramView, c(paramView), paramPaint);
    paramView.invalidate();
  }
  
  public int c(View paramView)
  {
    return aj.a(paramView);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ab
 * JD-Core Version:    0.7.0.1
 */