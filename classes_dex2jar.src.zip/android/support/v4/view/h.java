package android.support.v4.view;

import android.view.KeyEvent;

class h
  extends g
{
  public void a(KeyEvent paramKeyEvent)
  {
    k.a(paramKeyEvent);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.h
 * JD-Core Version:    0.7.0.1
 */