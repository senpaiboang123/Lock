package android.support.v4.view;

import android.view.KeyEvent;

abstract interface j
{
  public abstract void a(KeyEvent paramKeyEvent);
  
  public abstract boolean a(int paramInt1, int paramInt2);
  
  public abstract boolean b(int paramInt);
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.j
 * JD-Core Version:    0.7.0.1
 */