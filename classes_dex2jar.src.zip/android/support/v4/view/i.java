package android.support.v4.view;

class i
  extends h
{
  public int a(int paramInt)
  {
    return l.a(paramInt);
  }
  
  public boolean a(int paramInt1, int paramInt2)
  {
    return l.a(paramInt1, paramInt2);
  }
  
  public boolean b(int paramInt)
  {
    return l.b(paramInt);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.i
 * JD-Core Version:    0.7.0.1
 */