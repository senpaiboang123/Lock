package android.support.v4.view;

import android.view.View;

class ad
  extends ac
{
  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    al.a(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void a(View paramView, Runnable paramRunnable)
  {
    al.a(paramView, paramRunnable);
  }
  
  public void b(View paramView)
  {
    al.a(paramView);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ad
 * JD-Core Version:    0.7.0.1
 */