package android.support.v4.view;

import android.view.View;

class ah
{
  public static boolean a(View paramView)
  {
    return paramView.isOpaque();
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ah
 * JD-Core Version:    0.7.0.1
 */