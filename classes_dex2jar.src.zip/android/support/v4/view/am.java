package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

class am
{
  public static int a(View paramView)
  {
    return paramView.getLayoutDirection();
  }
  
  public static void a(View paramView, Paint paramPaint)
  {
    paramView.setLayerPaint(paramPaint);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.am
 * JD-Core Version:    0.7.0.1
 */