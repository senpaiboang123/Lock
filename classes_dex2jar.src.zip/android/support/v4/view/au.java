package android.support.v4.view;

import android.view.View;

public abstract interface au
{
  public abstract void a(View paramView, float paramFloat);
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.au
 * JD-Core Version:    0.7.0.1
 */