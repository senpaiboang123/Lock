package android.support.v4.view;

class c
  implements b
{
  public int a(int paramInt1, int paramInt2)
  {
    return 0xFF7FFFFF & paramInt1;
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.c
 * JD-Core Version:    0.7.0.1
 */