package android.support.v4.view;

class aq
{
  Object a;
  int b;
  boolean c;
  float d;
  float e;
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.aq
 * JD-Core Version:    0.7.0.1
 */