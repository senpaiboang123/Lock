package android.support.v4.view;

abstract interface b
{
  public abstract int a(int paramInt1, int paramInt2);
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.b
 * JD-Core Version:    0.7.0.1
 */