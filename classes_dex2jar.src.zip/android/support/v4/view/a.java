package android.support.v4.view;

import android.os.Build.VERSION;

public class a
{
  static final b a = new c();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 17)
    {
      a = new d();
      return;
    }
  }
  
  public static int a(int paramInt1, int paramInt2)
  {
    return a.a(paramInt1, paramInt2);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.a
 * JD-Core Version:    0.7.0.1
 */