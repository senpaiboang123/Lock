package android.support.v4.view;

import android.os.Parcel;
import android.support.v4.b.c;

final class aw
  implements c
{
  public ViewPager.SavedState b(Parcel paramParcel, ClassLoader paramClassLoader)
  {
    return new ViewPager.SavedState(paramParcel, paramClassLoader);
  }
  
  public ViewPager.SavedState[] b(int paramInt)
  {
    return new ViewPager.SavedState[paramInt];
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.aw
 * JD-Core Version:    0.7.0.1
 */