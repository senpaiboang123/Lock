package android.support.v4.view;

import android.view.MotionEvent;

class o
  implements p
{
  public int a(MotionEvent paramMotionEvent)
  {
    return q.a(paramMotionEvent);
  }
  
  public int a(MotionEvent paramMotionEvent, int paramInt)
  {
    return q.a(paramMotionEvent, paramInt);
  }
  
  public int b(MotionEvent paramMotionEvent, int paramInt)
  {
    return q.b(paramMotionEvent, paramInt);
  }
  
  public float c(MotionEvent paramMotionEvent, int paramInt)
  {
    return q.c(paramMotionEvent, paramInt);
  }
  
  public float d(MotionEvent paramMotionEvent, int paramInt)
  {
    return q.d(paramMotionEvent, paramInt);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.o
 * JD-Core Version:    0.7.0.1
 */