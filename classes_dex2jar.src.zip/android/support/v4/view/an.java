package android.support.v4.view;

import java.util.Comparator;

final class an
  implements Comparator
{
  public int a(aq paramaq1, aq paramaq2)
  {
    return paramaq1.b - paramaq2.b;
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.an
 * JD-Core Version:    0.7.0.1
 */