package android.support.v4.view;

class d
  implements b
{
  public int a(int paramInt1, int paramInt2)
  {
    return e.a(paramInt1, paramInt2);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.d
 * JD-Core Version:    0.7.0.1
 */