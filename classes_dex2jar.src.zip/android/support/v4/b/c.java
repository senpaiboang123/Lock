package android.support.v4.b;

import android.os.Parcel;

public abstract interface c
{
  public abstract Object a(Parcel paramParcel, ClassLoader paramClassLoader);
  
  public abstract Object[] a(int paramInt);
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.c
 * JD-Core Version:    0.7.0.1
 */