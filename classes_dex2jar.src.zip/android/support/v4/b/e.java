package android.support.v4.b;

import android.os.Parcelable.Creator;

class e
{
  static Parcelable.Creator a(c paramc)
  {
    return new d(paramc);
  }
}


/* Location:           C:\Users\PC\Desktop\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.b.e
 * JD-Core Version:    0.7.0.1
 */